
#ifndef SIMPLENODE_H
#define SIMPLENODE_H
#include <iostream>
using namespace std;

class SimpleNode {
private:
    int nodeId;
    int NeighborCount;
    SimpleNode* arrNeighbors;
public:
//constructor
    SimpleNode();
    SimpleNode(int nodeId);
    //func
    void addEdge(SimpleNode& n);

    SimpleNode& getneighbor();
    //getter setter
    int getneighborcount();

    void setNodeId(int& nodeId);
    void setNeighborCount(int& NeighborCount);
    void setarrNeighbors(SimpleNode*& arrNeighbors);

    int getNodeId();
//func
    void displayNeighbor();
//destruct
     ~SimpleNode();
};


#endif //RAYAN_PROJECT_SIMPLENODE_H
