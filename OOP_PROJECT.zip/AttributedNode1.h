
#ifndef ATTRIBUTEDNODE1_H
#define ATTRIBUTEDNODE1_H
//ATTRIBUTED NODE1

class AttributedNode1 {
private:
    char Gender;
    int Age;
public:
//const destruct
    AttributedNode1();
    ~AttributedNode1();
//setter getter
    void setGender(char Gender);
    void setAge(int Age);

    char getGender();
    int getAge();
//func
    void displayAttribute1();
};


#endif 
