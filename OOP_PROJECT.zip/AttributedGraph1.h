//Q2
#ifndef ATTRIBUTEDGRAPH1_H
#define ATTRIBUTEDGRAPH1_H
#include "SimpleGraph.h"
#include "AttributedNode1.h"
//ATTRIBUTE GRAPH1

class AttributedGraph1: public SimpleGraph{ //parent simple graph
private:
    AttributedNode1* arrAttributedNode1; //used to create an array of AttributedNode1
public:
//constructor destructor
    AttributedGraph1();
    ~AttributedGraph1();
//member func
    void appendAttributes();
    void printGraphData();
};


#endif 
